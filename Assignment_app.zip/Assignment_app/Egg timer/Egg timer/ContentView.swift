import SwiftUI

struct ContentView: View {
    let presets = [
        ("Soft Boiled", 240),
        ("Medium Boiled", 360),
        ("Hard Boiled", 480)
    ]

    var body: some View {
        NavigationView {
            VStack(spacing: 30) {
                Text("Egg Timer")
                    .font(.largeTitle)
                    .bold()
                
                
                ForEach(presets, id: \.0) { preset in
                    NavigationLink(
                        destination: TimerScreen(label: preset.0, duration: preset.1)
                    ) {
                        EggCard(label: preset.0, time: preset.1)
                    }
                }

                Spacer()
            }
            .padding()
        }
    }
}

#Preview {
    ContentView()
}
