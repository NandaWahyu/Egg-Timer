//
//  Egg_timerApp.swift
//  Egg timer
//
//  Created by Nanda Wahyu on 5/19/25.
//

import SwiftUI

@main
struct Egg_timerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
