import SwiftUI

struct EggCard: View {
    let label: String
    let time: Int

    var body: some View {
        VStack(spacing: 10) {
            Image("egg")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 60, height: 60)
            
            Text(label)
                .font(.headline)
            
            Text("Time = \(time / 60) mins")
                .font(.subheadline)
        }
        .frame(width: 200, height: 150)
        .background(Color.yellow.opacity(0.2))
        .cornerRadius(16)
        .shadow(radius: 3)
    }
}
#Preview {
    EggCard (label: "Egg", time: 120)
}
