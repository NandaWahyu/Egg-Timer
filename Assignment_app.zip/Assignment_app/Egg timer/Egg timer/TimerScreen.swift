import SwiftUI
import AVFoundation

struct TimerScreen: View {
    let label: String
    let duration: Int
    @State private var timeLeft: Int = 0
    @State private var timer: Timer?
    @State private var isRunning = false
    @State private var player: AVAudioPlayer?
    @Environment(\.dismiss) var dismiss

    var body: some View {
        VStack(spacing: 30) {
            Text("Egg Timer")
                .font(.largeTitle)
                .bold()

            ZStack {
                Image("egg")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
            
                    .scaleEffect(isRunning ? 1.3 : 1.0)
                    
            }
            .frame(height: 180)

            Text(label)
                .font(.title2)

            Text("Your egg will be ready in")
            Text(formatTime(timeLeft))
                .font(.system(size: 32, weight: .bold, design: .monospaced))
    
            
            if isRunning {
                Button("End Timer") {
                    stop()
                    dismiss()
                }
                .padding()
                .foregroundColor(.white)
                .background(Color.red)
                .cornerRadius(8)
            }
                    

            Spacer()
        }
        .padding()
        .onAppear {
            timeLeft = duration
            if !isRunning {
                start()
            }
        }
    }

    func formatTime(_ totalSeconds: Int) -> String {
        let mins = totalSeconds / 60
        let secs = totalSeconds % 60
        return String(format: "%02d:%02d", mins, secs)
    }

    func start() {
        stop() // reset previous
        isRunning = true
        timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { _ in
            if timeLeft > 0 {
                timeLeft -= 1
            } else {
                stop()
                playSound()
            }
        }
    }

    func stop() {
        timer?.invalidate()
        timer = nil
        isRunning = false
        timeLeft = duration  // reset to original duration
    }

    func playSound() {
        guard let url = Bundle.main.url(forResource: "alarm", withExtension: "mp3") else { return }
        player = try? AVAudioPlayer(contentsOf: url)
        player?.play()
    }
}


#Preview {
    ContentView()
}
