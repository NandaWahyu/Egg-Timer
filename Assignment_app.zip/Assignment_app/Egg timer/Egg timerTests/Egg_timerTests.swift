//
//  Egg_timerTests.swift
//  Egg timerTests
//
//  Created by Nanda Wahyu on 5/19/25.
//

import Testing
@testable import Egg_timer

struct Egg_timerTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
